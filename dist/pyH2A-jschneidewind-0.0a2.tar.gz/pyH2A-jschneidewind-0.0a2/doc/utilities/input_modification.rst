input_modification
==================

.. automodule:: pyH2A.Utilities.input_modification
    :members: