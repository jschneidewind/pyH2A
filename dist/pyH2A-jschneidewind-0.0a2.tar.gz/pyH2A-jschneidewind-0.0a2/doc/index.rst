.. pyH2A documentation master file, created by
   sphinx-quickstart on Fri Sep 10 16:22:36 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

pyH2A
=====

.. toctree::
   :maxdepth: 2
   :caption: Contents

   guide
   pyH2A/pyH2A
   utilities/utilities
   plugins/plugins
   analysis/analysis

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
