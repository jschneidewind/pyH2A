Fixed_Operating_Cost_Plugin
===========================

.. automodule:: pyH2A.Plugins.Fixed_Operating_Cost_Plugin
    :members: