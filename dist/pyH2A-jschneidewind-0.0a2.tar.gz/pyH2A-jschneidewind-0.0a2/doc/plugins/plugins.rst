Plugins
=======

.. toctree::
   :maxdepth: 1
   :caption: Plugins

   Capital_Cost_Plugin
   Fixed_Operating_Cost_Plugin
   Hourly_Irradiation_Plugin
   Multiple_Modules_Plugin
   PEC_Plugin
   Photocatalytic_Plugin
   Photovoltaic_Plugin
   Production_Scaling_Plugin
   Replacement_Plugin
   Solar_Concentrator_Plugin
   Solar_Thermal_Plugin
   Variable_Operating_Cost_Plugin

