Solar_Thermal_Plugin
====================

.. automodule:: pyH2A.Plugins.Solar_Thermal_Plugin
    :members: