Hourly_Irradiation_Plugin
=========================

.. automodule:: pyH2A.Plugins.Hourly_Irradiation_Plugin
    :members: